<?php

$num = $_GET['num'];

echo "$num";
?>